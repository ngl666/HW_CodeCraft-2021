package com.huawei.java.main.Dao;

import com.huawei.java.main.lib.Data;
import com.huawei.java.main.lib.Server;
import com.huawei.java.main.lib.Servernode;
import com.huawei.java.main.lib.VM;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class Tools {


    //编号计数,用于编号映射hashMap <申请时服务器的编号, 输出时服务器的编号>
    public static int numberCount = 0;
    //编号映射hashMap <申请时服务器的编号, 输出时服务器的编号>
    public static HashMap<Integer,Integer> severNumberMapping = new HashMap<>();


    //当前所有已购买服务器,有唯一id,购买时生成
//    public static HashMap<Integer, Server> currentAllServers = new HashMap<>();
    public static ArrayList<Server> currentAllServers = new ArrayList<>();//根据服务器编号获取服务器类
    public static ArrayList<ArrayList<Integer>>  dailyBuyServers =new ArrayList<>();//根据第几天获取第几天所购买的服务器id
    public static HashMap<Integer,ArrayList<Integer>> VMidInServer = new HashMap<>(); // <VM编号，[所部署的Server编号,部署的节点]> 1，2，表示节点，3表示双节点

    //当前所有已部署虚拟机，add请求时添加
    public static HashMap<Integer, VM> currentVm = new HashMap<>();
    public static ArrayList<ArrayList<Integer>> dailyArrangeVM = new ArrayList<>();//根据第几天获取第几天部署，第几天删除 ,可能当天创建后当天删除

//    public static ArrayList<VM> currentVm = new ArrayList<>();


    //所有可选服务器类<服务器类型，服务器类>
    public static HashMap<String, Server> allServerObject = new HashMap<>();
    //所有可选虚拟机类<虚拟机类型，虚拟机类>
    public static HashMap<String, VM> allVmObject = new HashMap<>();
    //所有请求
    public static ArrayList<String>[]op;

    //加载数据
    public static void downLoad(){
        //得到所有数据
        Data data= getdata.dataloader();
        //所有可选服务器
        ArrayList<String>allserinfo=data.getServersinfo();
        //所有可选服务器类<服务器类型，服务器类>
//        HashMap<String, Server> allServerObject = new HashMap<>();
        for(String server :allserinfo){
            //去括号
            server = server.substring(1,server.length()-1);
            server =server.replaceAll(" ","");
            String[] info = server.split(",");
            String model =info[0];
            int num_cpu = Integer.parseInt(info[1]);
            int RAM = Integer.parseInt(info[2]);
            int hardware_cost =Integer.parseInt(info[3]);
            int perday_cost = Integer.parseInt(info[4]);

            Server serverObject = new Server(num_cpu,RAM, model,hardware_cost,perday_cost);
            allServerObject.put(model,serverObject);
        }
//        System.out.println(allServerObject);


        //所有可选虚拟机
        ArrayList<String>allvminfo=data.getVminfo();

        for(String vm :allvminfo){
            //去括号
            vm = vm.substring(1,vm.length()-1);
            vm = vm.replaceAll(" ","");
            String model = vm.split(",")[0];
            int num_cpu = Integer.parseInt(vm.split(",")[1]);
            int RAM = Integer.parseInt(vm.split(",")[2]);
            int nodetype = Integer.parseInt(vm.split(",")[3]);
            try {
                VM vmObject = new VM( model,num_cpu,RAM,nodetype,0);
                allVmObject.put(model,vmObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
//        System.out.println(allVmObject);

        //所有请求
        op=data.getSequence();
    }

    /**
     *
     * @param server 当前服务器
     * @param vm 需要判断是否可以部署的虚拟机
     * @return 返回isArrange[3] 单节点：isArrange[0] isArrange[1]保存服务器节点12是否可以部署VM 1为可以，，isArrange[2]服务器节点是否可以部署VM 1为可以
     */
    //判断当前sever是否可以部署当前VM,
    public static int[]  isCanArrange(Server server,VM vm){
        int needGpu = vm.getNum_cpu();
        int needRam = vm.getRAM();
        int needNodeType = vm.getNodetype();
        Servernode servernode1 =server.getNode1();
        Servernode servernode2 =server.getNode2();
        int []isArrange = new int[3];
        isArrange[0]=0;
        isArrange[1]=0;
        isArrange[2]=0;


        if(needNodeType == 0){
             if((servernode1.getNum_cpu() - servernode1.getCpuisoccupied()) >= needGpu && (servernode1.getRAM() - servernode1.getRAMisoccupied()) >= needRam){
                 isArrange[0] = 1;
             }
             if((servernode2.getNum_cpu() - servernode2.getCpuisoccupied()) >= needGpu && (servernode2.getRAM() - servernode2.getRAMisoccupied()) >= needRam){
                isArrange[1] = 1;
             }

             return isArrange;

        }else {
            if((servernode1.getNum_cpu() - servernode1.getCpuisoccupied()) >= (needGpu/2) && (servernode1.getRAM() - servernode1.getRAMisoccupied()) >= (needRam/2)
                    &&(servernode2.getNum_cpu() - servernode2.getCpuisoccupied()) >= (needGpu/2) && (servernode2.getRAM() - servernode2.getRAMisoccupied()) >= (needRam/2)){
                isArrange[2] = 1;
            }

            return isArrange;
        }

    }


    //根据虚拟机购买服务器，返回购买的服务器
    /**
     *
     *
     * @param addVm  需要部署的虚拟机
     * @param i 第i天买的
     * @return 购买的服务器
     */
    public static Server buyServer(VM addVm,int i){

        Set<String> allCanUseServerType = allServerObject.keySet();
        Server oneServer = null;//一个server类，该类为真正要部署的server
        //遍历每个可以用的服务器
        for(String canUseServerType :allCanUseServerType){
            Server canUseServerObject = allServerObject.get(canUseServerType);
            //new 一个server类，该类为真正要部署的server
            oneServer = new Server(canUseServerObject.getNum_cpu(),canUseServerObject.getRAM(),canUseServerObject.getModel(),canUseServerObject.getHardware_cost(),canUseServerObject.getPerday_cost());
            int[] isArray =Tools.isCanArrange(oneServer,addVm);
            //虚拟机部署只需要单节点
            if(addVm.getNodetype() == 0){
                if(isArray[0] == 1){//当前服务器节点1可以部署
                    //暂时可以部署就选它，以后根据算法

                    int index = currentAllServers.size();//根据当前服务器个数为编号，因为编号从0开始，当前有0台，购买第一台编号为0
                    oneServer.setIndex(index);//设置编号

                    oneServer =Tools.arrangeVm(addVm,oneServer,1,i);
                    Tools.currentAllServers.add(oneServer);
                    if(dailyBuyServers.size() <= i){//这一天还没买，构建第i天买的服务器id数组
                        ArrayList<Integer> indexNumber = new ArrayList<>();
                        indexNumber.add(index);
                        dailyBuyServers.add(indexNumber);
                    }else {
                        dailyBuyServers.get(i).add(index);
                    }
                    return oneServer;

                }else if(isArray[1] == 1){//当前服务器节点2可以部署

                    int index = currentAllServers.size();//根据当前服务器个数为编号，因为编号从0开始，当前有0台，购买第一台编号为0
                    oneServer.setIndex(index);//设置编号

                    oneServer =Tools.arrangeVm(addVm,oneServer,2,i);
                    Tools.currentAllServers.add(oneServer);
                    if(dailyBuyServers.size() <= i){//这一天还没买，构建第i天买的服务器id数组
                        ArrayList<Integer> indexNumber = new ArrayList<>();
                        indexNumber.add(index);
                        dailyBuyServers.add(indexNumber);
                    }else {
                        dailyBuyServers.get(i).add(index);
                    }
                    return oneServer;

                }else{//当前服务器节点不可以部署,继续下一个
                    continue;
                }
            }else if(addVm.getNodetype() == 1){
                if(isArray[2] == 1){
                    //双节点可以部署
                    int index = currentAllServers.size();//根据当前服务器个数为编号，因为编号从0开始，当前有0台，购买第一台编号为0
                    oneServer.setIndex(index);//设置编号

                    oneServer =Tools.arrangeVm(addVm,oneServer,3,i);
                    Tools.currentAllServers.add(oneServer);
                    if(dailyBuyServers.size() <= i){//这一天还没买，构建第i天买的服务器id数组
                        ArrayList<Integer> indexNumber = new ArrayList<>();
                        indexNumber.add(index);
                        dailyBuyServers.add(indexNumber);
                    }else {
                        dailyBuyServers.get(i).add(index);
                    }

                    return oneServer;
                }else {
                    //不可以部署
                    continue;
                }
            }
        }
        return oneServer;
    }

    /**
     *
     * @param vm 需要部署的vm
     * @param server 部署在该服务器上
     * @param nodeNumber 部署在该节点上 1，2，表示节点，3表示双节点
     * @return 已部署的
     */
    public static Server arrangeVm(VM vm,Server server,int nodeNumber,int i){

        if(nodeNumber ==1){
            if(server.isIsopen() == false){
                server.setIsopen(true); //不用算钱


            }
            server.getNode1().setCpuisoccupied(server.getNode1().getCpuisoccupied()+vm.getNum_cpu());
            server.getNode1().setRAMisoccupied(server.getNode1().getRAMisoccupied()+vm.getRAM());

        }else if(nodeNumber == 2){
            if(server.isIsopen() == false){
                server.setIsopen(true); //不用算钱


            }
            server.getNode2().setCpuisoccupied(server.getNode2().getCpuisoccupied()+vm.getNum_cpu());
            server.getNode2().setRAMisoccupied(server.getNode2().getRAMisoccupied() +vm.getRAM());

        }else if(nodeNumber == 3){
            if(server.isIsopen() == false){
                server.setIsopen(true); //不用算钱

            }
            server.getNode1().setCpuisoccupied(server.getNode1().getCpuisoccupied()+vm.getNum_cpu()/2);
            server.getNode1().setRAMisoccupied(server.getNode1().getRAMisoccupied()+vm.getRAM()/2);
            server.getNode2().setCpuisoccupied(server.getNode2().getCpuisoccupied()+vm.getNum_cpu()/2);
            server.getNode2().setRAMisoccupied(server.getNode2().getRAMisoccupied()+vm.getRAM()/2);
        }else {
            System.out.println("nodeNumber 指定错误！！！");
        }
        ArrayList<Integer> serverIdAndNodeNumber =new ArrayList<>();
        serverIdAndNodeNumber.add(server.getIndex());
        serverIdAndNodeNumber.add(nodeNumber);
        VMidInServer.put(vm.getId(),serverIdAndNodeNumber);//<VM编号，[所部署的Server编号,部署的节点]>
        if(dailyArrangeVM.size() <= i){//这一天还没部署，构建第i天部署的服务器
            ArrayList<Integer>  vmId= new ArrayList<>();
            vmId.add(vm.getId());
            dailyArrangeVM.add(vmId);
        }else {
            dailyArrangeVM.get(i).add(vm.getId());
        }
        currentVm.put(vm.getId(),vm);
        return server;

    }
    //删除VM
    public static void deleteVM(int deleteVmId){

        ArrayList<Integer> serveridList = VMidInServer.get(deleteVmId);//部署的服务器

        int serverid =serveridList.get(0);//所部署的服务器编号
        int nodetype =serveridList.get(1);//所部署的服务器节点1，2，表示节点，3表示双节点
        Server server =currentAllServers.get(serverid);
        VM deletevm = currentVm.get(deleteVmId);
        if(nodetype ==1){
            server.getNode1().setCpuisoccupied(server.getNode1().getCpuisoccupied() - deletevm.getNum_cpu());
            server.getNode1().setRAMisoccupied(server.getNode1().getRAMisoccupied() - deletevm.getRAM());

        }else if(nodetype == 2){
            server.getNode2().setCpuisoccupied(server.getNode2().getCpuisoccupied() - deletevm.getNum_cpu());
            server.getNode2().setRAMisoccupied(server.getNode2().getRAMisoccupied() - deletevm.getRAM());

        }else if(nodetype == 3){
            server.getNode1().setCpuisoccupied(server.getNode1().getCpuisoccupied() - (deletevm.getNum_cpu()/2));
            server.getNode1().setRAMisoccupied(server.getNode1().getRAMisoccupied() - (deletevm.getRAM()/2));
            server.getNode2().setCpuisoccupied(server.getNode2().getCpuisoccupied() - (deletevm.getNum_cpu()/2));
            server.getNode2().setRAMisoccupied(server.getNode2().getRAMisoccupied() - (deletevm.getRAM()/2));

        }
    }

    //处理所有请求
    public static void processRequests(){
        for (int i = 0; i < op.length; i++) {
            //第i天的所有请求
            ArrayList<String>today=op[i];
            //初始化存每天买的服务器、每天部署的虚拟机的ArrayList
            ArrayList<Integer> indexNumber = new ArrayList<>();
            dailyBuyServers.add(indexNumber);
            ArrayList<Integer>  vmId= new ArrayList<>();
            dailyArrangeVM.add(vmId);

            //遍历每条请求
            for(int j=0; j<today.size();j++){
                //当前这条请求String
                String oneRequest = today.get(j);
                oneRequest =oneRequest.substring(1,oneRequest.length()-1);
                String []oneRequestInfo = oneRequest.split(", ");
                //请求类型
                String oneRequestType = oneRequestInfo[0];
                if(oneRequestType.equals("add")){
//                    System.out.println("添加请求");
                    //获取请求添加的VM的信息
                    String addVmModel = oneRequestInfo[1];
                    int addVmId = Integer.parseInt(oneRequestInfo[2]);
                    int addVmum_cpu = allVmObject.get(addVmModel).getNum_cpu();
                    int addVmRAM = allVmObject.get(addVmModel).getRAM();
                    int addVmNodetype = allVmObject.get(addVmModel).getNodetype();

                    VM addVm = new VM(addVmModel,addVmum_cpu,addVmRAM,addVmNodetype,addVmId);

//                    System.out.println(addVmId+"  "+addVmModel+"  "+addVmum_cpu+"  "+addVmRAM+"  "+addVmNodetype);
                    //遍历当前已购买服务器，是否有可部署的服务器
                    Boolean isArrange = false;//记录原来已经买的服务器是否可以完成此虚拟机的部署

                    for(int k=0;k<currentAllServers.size();k++){
                        Server oneServer = currentAllServers.get(k);
                        //判断该服务器是否可以满足部署条件
                        int[] isArray =Tools.isCanArrange(oneServer,addVm);

                        if(addVmNodetype == 0){//单节点
                            if(isArray[0] ==1){
                                //在已有服务器节点1上部署
                                oneServer =Tools.arrangeVm(addVm,oneServer,1,i);
                                currentAllServers.set(k,oneServer);
                                isArrange = true;
                                break;
                            }else if(isArray[1] ==1){
                                //在已有服务器节点2上部署
                                oneServer =Tools.arrangeVm(addVm,oneServer,2,i);
                                currentAllServers.set(k,oneServer);
                                isArrange = true;
                                break;
                            }else {
                                //该服务器上不能部署
                                continue;
                            }

                        }else if(addVmNodetype == 1){//双节点
                            if(isArray[2] == 1){
                                //在已有服务器两节点上上部署
                                oneServer =Tools.arrangeVm(addVm,oneServer,3,i);
                                currentAllServers.set(k,oneServer);
                                isArrange = true;
                                break;
                            }else {
                                continue;
                            }

                        }else{
                            System.out.println("addVmNodetype Error!");
                        }
                    }
                    if(isArrange == false){
                        //已有服务器不可以部署该虚拟机，选择服务器 部署虚拟机,第 i天部署
                        Tools.buyServer(addVm,i);
                    }

                }else if(oneRequestType.equals("del")){
//                    System.out.println("删除请求");
                    int deleteVmId = Integer.parseInt(oneRequestInfo[1]);
                    deleteVM(deleteVmId);



                }else {
                    System.out.println("请求错误！！！");


                }
            }
            //统计第i天需要买什么
//            System.out.println(dailyBuyServers.get(i));
            ArrayList<Integer> serverIdNumber=dailyBuyServers.get(i);
            //<型号，这一天该类服务器的所有类>
            HashMap<String,ArrayList<Server>> serverNumberObject = new HashMap<>();
            for(int e=0;e<serverIdNumber.size();e++){//遍历买什么
                Integer serverId = serverIdNumber.get(e);
                Server server =currentAllServers.get(serverId);

                if(serverNumberObject.containsKey(server.getModel())){
                    serverNumberObject.get(server.getModel()).add(server);
                }else {
                    ArrayList<Server> oneTypeServer = new ArrayList<>();
                    oneTypeServer.add(server);
                    serverNumberObject.put(server.getModel(),oneTypeServer);
                }
            }
            //输出
            System.out.println("(purchase, "+serverNumberObject.size()+")");
            for(String serverType : serverNumberObject.keySet()){
                System.out.println("("+serverType+", "+serverNumberObject.get(serverType).size()+")");

                //构建编号映射hashMap <申请时服务器的编号, 输出时服务器的编号>
                for(Server oneserver:serverNumberObject.get(serverType)){

                    severNumberMapping.put(oneserver.getIndex(),numberCount++);

                }
            }
            System.out.println("(migration, " +"0"+")");



            //输出节点怎么部署
//            System.out.println(dailyArrangeVM.get(i));
            ArrayList<Integer> vmIdNumber=dailyArrangeVM.get(i);
            for(int r=0;r<vmIdNumber.size();r++){
                ArrayList<Integer> serveridList = VMidInServer.get(vmIdNumber.get(r));//部署的服务器
                int serverid =serveridList.get(0);//服务器编号
                int nodetype =serveridList.get(1);//服务器节点1，2，表示节点，3表示双节点
                if(nodetype ==1){
                    System.out.println("("+severNumberMapping.get(serverid)+", A)" );
                }else if(nodetype == 2){
                    System.out.println("("+severNumberMapping.get(serverid)+", B)" );

                }else if(nodetype == 3){
                    System.out.println("("+severNumberMapping.get(serverid)+")" );
                }
            }



        }
    }





}
