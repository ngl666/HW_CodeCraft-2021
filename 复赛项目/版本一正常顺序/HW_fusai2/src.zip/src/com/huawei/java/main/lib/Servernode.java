package com.huawei.java.main.lib;

public class Servernode{
    private int num_cpu;
    private int RAM;
    private String nodename;
    //被占用多少
    private int cpuisoccupied;
    private int RAMisoccupied;

    public Servernode(int num_cpu, int RAM, String nodename, int cpuisoccupied , int RAMisoccupied) {
        this.num_cpu = num_cpu;
        this.RAM = RAM;
        this.nodename = nodename;
        this.cpuisoccupied = cpuisoccupied;
        this.RAMisoccupied = RAMisoccupied;

    }

    public Servernode(int num_cpu, int RAM, String nodename) {
        this.num_cpu=num_cpu;
        this.RAM=RAM;
        this.nodename=nodename;
        this.cpuisoccupied=0;
        this.RAMisoccupied=0;

    }

    public String getNodename() {
        return nodename;
    }


    public void setNodename(String nodename) {
        this.nodename = nodename;
    }

    public int getNum_cpu() {
        return num_cpu;
    }

    public void setNum_cpu(int num_cpu) {
        this.num_cpu = num_cpu;
    }

    public int getRAM() {
        return RAM;
    }

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }

    public int getCpuisoccupied() {
        return cpuisoccupied;
    }

    public void setCpuisoccupied(int cpuisoccupied) {
        this.cpuisoccupied = cpuisoccupied;
    }

    public int getRAMisoccupied() {
        return RAMisoccupied;
    }

    public void setRAMisoccupied(int RAMisoccupied) {
        this.RAMisoccupied = RAMisoccupied;
    }

    @Override
    public String toString() {
        return "Servernode{" +
                "num_cpu=" + num_cpu +
                ", RAM=" + RAM +
                ", nodename='" + nodename + '\'' +
                ", cpuisoccupied=" + cpuisoccupied +
                ", RAMisoccupied=" + RAMisoccupied +
                '}';
    }
}
